<?php
$config = [
    'setting' => [
        'displayErrorDetails' => true,
        'database' => [
            'hostname' => 'localhost',
            'dbname'   => 'kjymcotz_manda', 
            'username' => 'root',  
            'password' => ''          
        ],
    ],
];