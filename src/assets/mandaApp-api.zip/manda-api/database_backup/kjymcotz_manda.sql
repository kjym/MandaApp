

--
-- Database: `kjymcotz_manda`
--

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(32) NOT NULL,
  `firstname` varchar(30) NOT NULL,
  `lastname` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `password`, `firstname`, `lastname`) VALUES
(4, 'Danny', '3d717bf19b4075b4b3484417b0f9f183', 'Kulwa', 'Josephat'),
(5, 'KJYM', '3d717bf19b4075b4b3484417b0f9f183', 'Kulwa', 'Manda'),
(7, 'MandaKj', '827ccb0eea8a706c4c34a16891f84e7b', 'Kulwa', 'Josephat'),
(8, 'Benny', '827ccb0eea8a706c4c34a16891f84e7b', 'Benjamin', 'Mlaki'),
(10, 'Hans', '827ccb0eea8a706c4c34a16891f84e7b', 'Hassani', 'Zephania'),
(11, 'GozB', 'e10adc3949ba59abbe56e057f20f883e', 'Gozberth', 'Mashuleshule');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;


