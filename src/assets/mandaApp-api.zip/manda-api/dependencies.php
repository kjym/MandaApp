<?php
$container = $app->getContainer();
$container['db'] = function($c){
    $db = $c->get('setting')['database'];
  try{
    return  new PDO("mysql:host={$db['hostname']};dbname={$db['dbname']}", "{$db['username']}", "{$db['password']}");
  }catch(PDOException $e){
    var_dump($e);
    exit();
  }

};